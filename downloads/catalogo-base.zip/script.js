// PROJETO-BASE: o filtro ainda precisa ser implementado por você.
const botoes = document.querySelectorAll('[data-filtro]');
const cartoes = document.querySelectorAll('[data-categoria]');
const resultado = document.querySelector('#resultado');

// TODO 1: registre o evento click em cada botão.
// TODO 2: leia a categoria em botao.dataset.filtro.
// TODO 3: percorra cartoes e altere cartao.hidden.
// TODO 4: atualize aria-pressed e resultado.textContent.
// TODO 5: teste Todos, cada categoria e a navegação pelo teclado.
