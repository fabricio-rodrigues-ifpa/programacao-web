// Este roteiro trabalha a estrutura HTML. A interatividade pode vir depois.
