'use strict';
// Apoio fornecido: esta aula altera somente index.html.
const form = document.querySelector('#formulario');
const status = document.querySelector('#status');
const botao = document.querySelector('#simular');
// A página inicial ainda não tem form nem botão. Salve após cada etapa.
if (form) {
  form.addEventListener('input', () => { status.textContent = ''; });
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    status.textContent = 'As regras HTML permitiram esta tentativa. Simulação local; nenhum envio ao servidor.';
  });
  if (botao) botao.disabled = false;
}
