'use strict';
const form = document.querySelector('#formulario');
const status = document.querySelector('#status');
const botao = document.querySelector('#simular');
// Apoio de simulação fornecido pelo professor. A aula 02 altera o HTML.
form.addEventListener('submit', (event) => {
  event.preventDefault();
  status.textContent = 'As regras HTML permitiram esta tentativa. Simulação local; nenhum envio ao servidor.';
});
botao.disabled = false;
