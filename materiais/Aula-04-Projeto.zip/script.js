// WebLab · Apoio pronto para a oficina de 06/11/2026.
// Os alunos digitam os controles no index.html. Não é preciso alterar este JS.
// Tudo acontece no navegador: sem servidor de dados e sem armazenamento.
'use strict';

const formulario = document.querySelector('#formulario');
const resultado = document.querySelector('#resultado');
const linhas = document.querySelector('#linhas');
const status = document.querySelector('#status');

// A imagem fica embutida para manter o download com apenas três arquivos.
const imagem = document.querySelector('#enviar-imagem');
if (imagem) {
  const desenho = '<svg xmlns="http://www.w3.org/2000/svg" width="140" height="42"><rect width="140" height="42" rx="6" fill="#183e35"/><text x="70" y="27" text-anchor="middle" font-family="Arial" font-size="15" fill="white">Enviar imagem</text></svg>';
  imagem.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(desenho);
}

function atualizarNivel() {
  const nivel = formulario.querySelector('#nivel');
  const saida = formulario.querySelector('#valor-nivel');
  if (nivel && saida) saida.value = nivel.value;
}

function ocultarResultado() {
  if (!resultado.hidden) status.textContent = 'Dados alterados. Envie novamente para atualizar o resumo.';
  resultado.hidden = true;
}

formulario.addEventListener('input', () => {
  atualizarNivel();
  ocultarResultado();
});
formulario.addEventListener('change', ocultarResultado);

// O evento submit só é disparado depois de passar pelas regras nativas do HTML.
formulario.addEventListener('submit', (evento) => {
  evento.preventDefault();
  // O segundo argumento inclui o botão que acionou o envio.
  const dados = evento.submitter
    ? new FormData(formulario, evento.submitter)
    : new FormData(formulario);
  const grupos = new Map();
  for (const [nome, valor] of dados.entries()) {
    if (!grupos.has(nome)) grupos.set(nome, []);
    grupos.get(nome).push(valor);
  }

  // Guarda apenas os nomes dos campos de senha, para ocultar seus valores.
  const senhas = new Set(
    Array.from(formulario.querySelectorAll('input[type="password"]'))
      .map((campo) => campo.name)
  );

  linhas.replaceChildren();
  for (const [nome, valores] of grupos) {
    const linha = document.createElement('tr');
    const chave = document.createElement('th');
    const conteudo = document.createElement('td');
    chave.scope = 'row';
    chave.textContent = nome;
    conteudo.textContent = valores.map((valor) => {
      if (senhas.has(nome)) return valor ? '•••••• (senha ocultada)' : '(vazio)';
      if (valor instanceof File) {
        return valor.name ? `${valor.name} (${valor.size} bytes)` : '(nenhum arquivo selecionado)';
      }
      return valor === '' ? '(vazio)' : String(valor);
    }).join(' | ');
    linha.append(chave, conteudo);
    linhas.append(linha);
  }

  resultado.hidden = false;
  status.textContent = 'Resumo atualizado abaixo. Nenhum dado foi enviado a um servidor.';
  resultado.scrollIntoView({ behavior: 'smooth', block: 'start' });
  resultado.focus({ preventScroll: true });
});

// O reset nativo restaura os valores iniciais. Depois, atualizamos o output.
formulario.addEventListener('reset', () => {
  resultado.hidden = true;
  linhas.replaceChildren();
  status.textContent = 'Valores iniciais restaurados.';
  requestAnimationFrame(atualizarNivel);
});

// Um botão do tipo button precisa de uma ação programada.
formulario.addEventListener('click', (evento) => {
  if (evento.target.matches('[data-acao="contar"]')) {
    const quantidade = formulario.querySelectorAll('input, select, textarea, button').length;
    status.textContent = `Há ${quantidade} controles (incluindo botões e hidden). Este botão não envia.`;
  }
});
atualizarNivel();
