'use strict';
const form = document.querySelector('#formulario');
const status = document.querySelector('#status');
const botao = document.querySelector('#simular');
const resultado = document.querySelector('#resultado');
const resumo = document.querySelector('#dados-resumo');
const contato = document.querySelector('#contato');
const confirmar = document.querySelector('#confirmar');
const descricao = document.querySelector('#descricao');

function conferirContato() {
  const diferente = confirmar.value !== contato.value;
  confirmar.setCustomValidity(
    confirmar.value && diferente ? 'Repita o mesmo e-mail.' : ''
  );
}
contato.addEventListener('input', conferirContato);
confirmar.addEventListener('input', conferirContato);

function conferirDescricao() {
  const curta = descricao.value.length > 0
    && descricao.value.trim().length < 20;
  descricao.setCustomValidity(
    curta ? 'Descreva o problema com pelo menos 20 caracteres.' : ''
  );
}
descricao.addEventListener('input', conferirDescricao);

function adicionarLinha(titulo, valor) {
  const dt = document.createElement('dt');
  const dd = document.createElement('dd');
  dt.textContent = titulo;
  dd.textContent = String(valor);
  resumo.append(dt, dd);
}

function mostrarResumo(dados) {
  resumo.replaceChildren();
  adicionarLinha('Solicitante fictício', dados.get('solicitante') || '');
  adicionarLinha('Equipamento', dados.get('equipamento') || '');
  adicionarLinha('Contato fictício', dados.get('contato') || '');
  adicionarLinha('Categoria', dados.get('categoria') || '');
  adicionarLinha('Prioridade', dados.get('prioridade') || '');
  adicionarLinha('Descrição', dados.get('descricao') || '');
  adicionarLinha('Sintomas', dados.getAll('sintomas').join(', ') || 'Nenhum selecionado');
  resultado.hidden = false;
  status.textContent = 'Simulação concluída. Nenhum dado foi enviado ao servidor.';
  document.querySelector('#titulo-resumo').focus();
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  conferirContato();
  conferirDescricao();
  if (!form.reportValidity()) return;
  const dados = new FormData(form);
  mostrarResumo(dados);
});

form.addEventListener('invalid', () => {
  status.textContent = 'Confira o campo indicado. Seus valores foram mantidos.';
}, true);
form.addEventListener('input', () => {
  status.textContent = '';
  resultado.hidden = true;
});

document.querySelector('#novo').addEventListener('click', () => {
  form.reset();
  confirmar.setCustomValidity('');
  descricao.setCustomValidity('');
  resultado.hidden = true;
  resumo.replaceChildren();
  status.textContent = '';
  document.querySelector('#solicitante').focus();
});
botao.disabled = false;
