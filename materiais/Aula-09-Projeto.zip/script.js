'use strict';
const form = document.querySelector('#formulario');
const status = document.querySelector('#status');
const botao = document.querySelector('#simular');
const resultado = document.querySelector('#resultado');
const resumo = document.querySelector('#dados-resumo');
const contato = document.querySelector('#contato');
const confirmar = document.querySelector('#confirmar');
const descricao = document.querySelector('#objetivo');

function conferirContato() {
  const diferente = confirmar.value !== contato.value;
  confirmar.setCustomValidity(
    confirmar.value && diferente ? 'Repita o mesmo e-mail.' : ''
  );
}
contato.addEventListener('input', conferirContato);
confirmar.addEventListener('input', conferirContato);

function conferirDescricao() {
  const curta = descricao.value.length > 0
    && descricao.value.trim().length < 20;
  descricao.setCustomValidity(
    curta ? 'Descreva o problema com pelo menos 20 caracteres.' : ''
  );
}
descricao.addEventListener('input', conferirDescricao);

const categoria = document.querySelector('#oficina');
const outro = document.querySelector('#tema_sugerido');
const blocoOutro = document.querySelector('#bloco-outro');

function atualizarOutro() {
  const ativo = categoria.value === 'outro';
  blocoOutro.hidden = !ativo;
  outro.disabled = ativo;
  outro.required = ativo;
  if (!ativo) outro.value = '';
}
categoria.addEventListener('change', atualizarOutro);
atualizarOutro();

function adicionarLinha(titulo, valor) {
  const dt = document.createElement('dt');
  const dd = document.createElement('dd');
  dt.textContent = titulo;
  dd.textContent = String(valor);
  resumo.append(dt, dd);
}

function mostrarResumo(dados) {
  resumo.replaceChildren();
  adicionarLinha('Participante fictício', dados.get('participante') || '');
  adicionarLinha('Contato fictício', dados.get('contato') || '');
  adicionarLinha('Oficina', dados.get('oficina') || '');
  adicionarLinha('Turno', dados.get('turno') || '');
  adicionarLinha('Objetivo', dados.get('objetivo') || '');
  adicionarLinha('Materiais', dados.getAll('recursos').join(', ') || 'Nenhum selecionado');
  if (dados.has('tema_sugerido')) adicionarLinha('Outra opção', dados.get('tema_sugerido'));
  resultado.hidden = false;
  status.textContent = 'Simulação concluída. Nenhum dado foi enviado ao servidor.';
  document.querySelector('#titulo-resumo').focus();
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  conferirContato();
  conferirDescricao();
  if (!form.reportValidity()) return;
  const dados = new FormData();
  mostrarResumo(dados);
});

form.addEventListener('invalid', () => {
  status.textContent = 'Confira o campo indicado. Seus valores foram mantidos.';
}, true);
form.addEventListener('input', () => {
  status.textContent = '';
  resultado.hidden = true;
});

document.querySelector('#novo').addEventListener('click', () => {
  form.reset();
  confirmar.setCustomValidity('');
  descricao.setCustomValidity('');
  atualizarOutro();
  resultado.hidden = true;
  resumo.replaceChildren();
  status.textContent = '';
  document.querySelector('#participante').focus();
});
botao.disabled = false;
