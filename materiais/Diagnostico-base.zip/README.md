# Diagnóstico de HTML, CSS e JavaScript

WEBLAB - Diagnóstico de HTML, CSS e JavaScript
Professor Fabrício Rodrigues

COMO ABRIR
1. Extraia o ZIP em uma pasta sua. Não trabalhe dentro do ZIP.
2. No VS Code, escolha Arquivo > Abrir Pasta e selecione esta pasta.
3. Confira a extensão Live Server, de Ritwick Dey.
4. Clique com o botão direito em index.html e escolha Open with Live Server.
5. Edite index.html, style.css ou script.js. Salve com Ctrl+S e observe a página.
Não é necessário instalar pacotes npm. VS Code e Live Server devem estar instalados.

TAREFAS
1. Acrescente um cartão com título e descrição.
2. Corrija o estilo do destaque.
3. Faça o botão alternar os detalhes e teste dois cliques.
4. Registre suas mudanças e testes.
Há falhas intencionais nesta prática.

ENTREGA DURANTE A AULA
Preencha REGISTRO-DE-TESTES.txt. Compacte a pasta completa em ZIP, com nome
diagnostico-turma-seu-nome.zip, e entregue ao professor.
Use dados fictícios nos formulários. O protótipo não envia chamados reais.

REFERÊNCIAS COM LINKS (exigem internet)
Guia do WebLab: https://fabricio-rodrigues-ifpa.github.io/programacao-web/como-usar.html
Live Server: https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer
Formulários: https://developer.mozilla.org/pt-BR/docs/Learn_web_development/Extensions/Forms/Your_first_form
CSS Grid: https://developer.mozilla.org/pt-BR/docs/Web/CSS/CSS_grid_layout/Basic_concepts_of_grid_layout
Evento submit: https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/submit_event

RESPOSTAS DO DIAGNÓSTICO
Abra respostas.html com Live Server. Informe nome e turma, responda e baixe
o TXT no final. Confira Downloads e entregue o TXT ao professor na aula.
A página não envia nem salva automaticamente. Baixe antes de fechar ou recarregar.
