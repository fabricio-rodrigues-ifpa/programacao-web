const botao = document.querySelector("#mostar");
const painel = document.querySelector("#painel");
botao.addEventListener("click", () => {
  painel.hidden = !painel.hidden;
});
