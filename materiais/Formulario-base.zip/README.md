# Formulário de suporte ao laboratório

WEBLAB - Formulário de suporte ao laboratório
Professor Fabrício Rodrigues

COMO ABRIR
1. Extraia o ZIP em uma pasta sua. Não trabalhe dentro do ZIP.
2. No VS Code, escolha Arquivo > Abrir Pasta e selecione esta pasta.
3. Confira a extensão Live Server, de Ritwick Dey.
4. Clique com o botão direito em index.html e escolha Open with Live Server.
5. Edite index.html, style.css ou script.js. Salve com Ctrl+S e observe a página.
Não é necessário instalar pacotes npm. VS Code e Live Server devem estar instalados.

TAREFAS
Continue sua versão nas aulas seguintes; baixe esta base novamente somente se precisar recuperar os arquivos.
Aula 01: equipamento e descrição com rótulos.
Aula 02: campos, grupos e regras HTML.
Aula 03: CSS, foco e teclado.
Aula 04: FormData e resumo.
Aula 05: validação complementar.
Aula 06: percurso dos dados e requisitos.
Aula 07: campos condicionais e preparação.
Aula 08 (11/12): avaliação prática, testes e explicação individual.
Aula 09 (18/12): devolutiva, correções e recuperação.

ENTREGA DURANTE A AULA
Preencha REGISTRO-DE-TESTES.txt. Compacte a pasta completa em ZIP, com nome
formulario-turma-seu-nome.zip, e entregue ao professor.
Use dados fictícios nos formulários. O protótipo não envia chamados reais.

REFERÊNCIAS COM LINKS (exigem internet)
Guia do WebLab: https://fabricio-rodrigues-ifpa.github.io/programacao-web/como-usar.html
Live Server: https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer
Formulários: https://developer.mozilla.org/pt-BR/docs/Learn_web_development/Extensions/Forms/Your_first_form
CSS Grid: https://developer.mozilla.org/pt-BR/docs/Web/CSS/CSS_grid_layout/Basic_concepts_of_grid_layout
Evento submit: https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/submit_event
