// Base didática: o envio real fica desativado.
const form = document.querySelector("#chamado");
const resumo = document.querySelector("#resumo");

form.addEventListener("submit", (event) => {
  event.preventDefault();

  resumo.textContent = "Protótipo em construção. Nenhum dado foi enviado.";

  // Nas aulas, leia FormData e monte seu próprio resumo.
});
